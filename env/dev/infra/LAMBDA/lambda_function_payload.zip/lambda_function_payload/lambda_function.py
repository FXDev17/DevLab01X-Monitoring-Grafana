import json
import time
import boto3
import uuid
import random
import os
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.ext.boto3 import patch_all
from aws_lambda_powertools import Logger, Metrics, Tracer
from aws_lambda_powertools.metrics import MetricUnit

# Initialize AWS Lambda Powertools
logger = Logger(service="ping-api")
metrics = Metrics(namespace="PingAPI")
tracer = Tracer(service="ping-api")

# Patch Boto3 for X-Ray tracing
patch_all()

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.getenv('DYNAMODB_TABLE', 'RequestMetrics'))

@tracer.capture_lambda_handler
@logger.inject_lambda_context(log_event=True)
@metrics.log_metrics
def lambda_handler(event, context):
    try:
        # Generate request ID if not present
        request_id = event.get('requestContext', {}).get('requestId', str(uuid.uuid4()))
        path = event.get('path', '/')
        
        # Add custom context to logs
        logger.structure_logs(append=True, request_id=request_id, path=path)
        
        # Simulate work or failure
        if path == '/fail' and random.random() < 0.3:
            raise Exception("Simulated failure")
        
        # Simulate processing time
        processing_time = random.uniform(0.02, 0.1)
        time.sleep(processing_time)
        
        # Record successful request
        latency = processing_time * 1000
        timestamp = int(time.time())
        
        # Store in DynamoDB
        table.put_item(
            Item={
                'request_id': request_id,
                'timestamp': timestamp,
                'latency': latency,
                'path': path
            }
        )
        
        # Add custom metrics
        metrics.add_metric(name="Latency", unit=MetricUnit.Milliseconds, value=latency)
        metrics.add_metric(name="Requests", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="Path", value=path)
        
        # Return successful response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'pong',
                'latency': f'{latency:.2f}ms',
                'request_id': request_id
            }),
            'headers': {
                'Content-Type': 'application/json',
                'X-Request-ID': request_id
            }
        }
        
    except Exception as e:
        # Record error metrics
        metrics.add_metric(name="Errors", unit=MetricUnit.Count, value=1)
        logger.error(f"Request failed: {str(e)}")
        
        # Return error response
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'request_id': request_id
            }),
            'headers': {
                'Content-Type': 'application/json',
                'X-Request-ID': request_id
            }
        }