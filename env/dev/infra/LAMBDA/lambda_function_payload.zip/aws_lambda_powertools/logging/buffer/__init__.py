from aws_lambda_powertools.logging.buffer.config import LoggerBufferConfig

__all__ = ["LoggerBufferConfig"]
